# Bedrock-Formation-Locator

Finds Minecraft coordinates from bedrock patterns using world seeds. This is a Java-based tool that allows you to define custom bedrock patterns and search for them in a given Minecraft world seed.

## Features

*   Search for bedrock patterns in a given world seed.
*   Define custom patterns for different Y-levels.
*   Search for connected patterns across multiple Y-levels.
*   Multi-threaded search for faster results.

## Prerequisites

*   Java Development Kit (JDK) 17 or later.

## Getting Started

### 1. Building the Distribution

To build the application, run the following command:

```bash
./gradlew clean distribution
```

This will create a zip file named `Bedrock-Finder.zip` in the `app/build/distributions` directory.

### 2. Running the Application

1.  Unzip the `Bedrock-Finder.zip` file in a location of your choice.
2.  Edit the `config.json` file to configure your search parameters. For detailed information on all configuration options, please refer to the [Configuration Documentation](CONFIG_DOCUMENTATION.md).
3.  Run the application using the following command:

```bash
java -jar Bedrock-Finder.jar
```

The application will start searching for the configured bedrock patterns and print the coordinates of any matches to the console.

## Contributing

Contributions are welcome! If you have any ideas, suggestions, or bug reports, please open an issue or submit a pull request.

## License

This project is currently not licensed.
